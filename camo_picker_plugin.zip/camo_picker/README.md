# CamoPicker — QGIS Plugin

**Tactical Engine V12.1 "Luminance Spark" — адаптация для QGIS**

## Что делает плагин

1. Пользователь выбирает **полигональный слой** (охват) и **растровый слой** (спутник / QuickMapServices)
2. Плагин обходит каждый полигон → сэмплирует пиксели растра под ним
3. KMeans кластеризует доминантные цвета каждой зоны
4. TacticalCoreV12.1 генерирует паттерны: **Pixel Apex**, **Spots 850**, **Heritage Woodland**
5. Результат записывается как **GeoTIFF** и добавляется в проект QGIS как растровый слой

---

## Структура файлов

```
camo_picker/
├── __init__.py          # QGIS entry point
├── plugin.py            # Кнопка в тулбаре, запуск диалога
├── camo_dialog.py       # Диалоговое окно (PyQt5)
├── engine_worker.py     # Фоновый поток: пайплайн анализа
├── tactical_core.py     # TacticalCoreV12.1 (адаптирован)
├── metadata.txt         # Метаданные плагина
├── icons/
│   └── camo_icon.png    # Иконка (нужно добавить вручную)
└── resources/           # Локальный кэш БД камуфляжей (опционально)
```

---

## Установка

### 1. Зависимости Python

В окружении Python, которое использует QGIS:

```bash
pip install Pillow scikit-learn scikit-image mercantile rasterio requests
```

> **Windows / OSGeo4W:**
> Откройте `OSGeo4W Shell` и выполните:
> ```
> python -m pip install Pillow scikit-learn scikit-image mercantile rasterio requests
> ```

### 2. Установка плагина

- Скопируйте папку `camo_picker/` в директорию плагинов QGIS:
  - **Linux/Mac:** `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`
  - **Windows:** `%APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\`
- В QGIS: `Plugins → Manage and Install Plugins → Installed` → включите **CamoPicker**

### 3. Иконка

Положите иконку `camo_icon.png` (любой PNG 32×32) в папку `camo_picker/icons/`.

---

## Использование

1. Добавьте спутниковый растр (локальный или через QuickMapServices)
2. Добавьте полигональный слой с зонами (каждый полигон = отдельная зона)
3. Нажмите кнопку **CamoPicker** в тулбаре
4. Выберите слои, режим, нажмите **Run**
5. GeoTIFF-слои с паттернами добавятся в проект

---

## Режимы

| Режим | Паттерны |
|-------|----------|
| Full | Pixel Apex + Spots 850 + Heritage Woodland + Rescue Dazzle |
| Tactical only | Pixel Apex + Spots 850 + Heritage Woodland |
| Rescue / SAR | Rescue Dazzle + оценка High-Vis стандартов |

---

## Зависимости (ключевые)

| Библиотека | Роль |
|-----------|------|
| `rasterio` | Запись GeoTIFF с геопривязкой |
| `scikit-learn` | KMeans кластеризация цветов |
| `scikit-image` | CIE Lab / Delta-E вычисления |
| `Pillow` | Генерация паттернов |
| `mercantile` | Тайловые координаты (для standalone-режима) |

---

## Известные ограничения

- Полигон-маска (`_geometry_mask`) использует точечную проверку — на больших зонах при высоком sample_res работает медленно. В будущем — замена на `rasterio.features.geometry_mask`.
- `rasterio` опциональна: без неё плагин сохраняет простой PNG без геопривязки.
- Загрузка БД камуфляжей требует интернета. При отсутствии подключения — ранжирование пропускается.
