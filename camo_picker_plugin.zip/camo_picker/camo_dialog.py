# -*- coding: utf-8 -*-
"""
CamoPicker QGIS Plugin — camo_dialog.py
Dialog window: polygon extent selector, raster layer selector, mode,
radius, run button, progress bar, log output.
"""

import os
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QComboBox,
    QPushButton, QProgressBar, QTextEdit, QGroupBox,
    QRadioButton, QButtonGroup, QSpinBox, QSizePolicy, QCheckBox,
    QScrollArea, QWidget
)
from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
from qgis.core import (
    QgsProject, QgsMapLayer, QgsVectorLayer, QgsRasterLayer,
    QgsMessageLog, Qgis
)

from .engine_worker import EngineWorker


class CamoPickerDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.worker = None
        self.thread = None
        self._build_ui()

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------
    def _build_ui(self):
        self.setWindowTitle('CamoPicker — Tactical Pattern Generator')
        self.setMaximumHeight(720)
        self.setMinimumWidth(520)

        # Outer layout holds scroll area + fixed bottom bar
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 8)
        outer.setSpacing(0)

        # Scroll area for all controls
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.NoFrame)
        scroll_widget = QWidget()
        root = QVBoxLayout(scroll_widget)
        root.setSpacing(10)
        root.setContentsMargins(10, 10, 10, 4)
        scroll.setWidget(scroll_widget)
        outer.addWidget(scroll, 1)

        # --- Layer selection group ---
        grp_layers = QGroupBox('Input layers')
        lay_layers = QVBoxLayout(grp_layers)

        # Polygon extent layer
        row_poly = QHBoxLayout()
        row_poly.addWidget(QLabel('Polygon extent:'))
        self.cb_polygon = QComboBox()
        self.cb_polygon.setToolTip(
            'Select a polygon layer that defines the analysis area.\n'
            'Each feature becomes a separate terrain zone.'
        )
        row_poly.addWidget(self.cb_polygon, 1)
        lay_layers.addLayout(row_poly)

        # Raster layer
        row_raster = QHBoxLayout()
        row_raster.addWidget(QLabel('Satellite raster:'))
        self.cb_raster = QComboBox()
        self.cb_raster.setToolTip(
            'Active raster layer — local file or QuickMapServices tile.\n'
            'CamoPicker samples colors directly from this layer.'
        )
        row_raster.addWidget(self.cb_raster, 1)
        lay_layers.addLayout(row_raster)

        # Refresh button
        self.chk_selected_only = QCheckBox('Use selected features only')
        self.chk_selected_only.setChecked(False)
        self.chk_selected_only.setToolTip(
            'Process only features currently selected in the polygon layer.\n'
            'If nothing is selected, all features will be used.'
        )
        lay_layers.addWidget(self.chk_selected_only)

        btn_refresh = QPushButton('↻ Refresh layers')
        btn_refresh.clicked.connect(self.populate_layers)
        lay_layers.addWidget(btn_refresh)

        root.addWidget(grp_layers)

        # --- Classification settings ---
        grp_class = QGroupBox('Classification')
        lay_class = QVBoxLayout(grp_class)

        row_k = QHBoxLayout()
        row_k.addWidget(QLabel('Number of color clusters (K):'))
        self.spin_k = QSpinBox()
        self.spin_k.setRange(2, 10)
        self.spin_k.setValue(6)
        self.spin_k.setToolTip(
            'KMeans clusters per zone. 6 = forest/field/urban/shadow/highlight/ground.'
        )
        row_k.addWidget(self.spin_k)
        row_k.addStretch()
        lay_class.addLayout(row_k)

        # Zoom level
        row_zoom = QHBoxLayout()
        row_zoom.addWidget(QLabel('Target tile zoom:'))
        self.spin_zoom = QSpinBox()
        self.spin_zoom.setRange(10, 19)
        self.spin_zoom.setValue(17)
        self.spin_zoom.setToolTip(
            'Zoom level for tile sampling (like OSM/Google zoom).\n'
            '17-18 = street level detail, 14-15 = city level.\n'
            'Higher = sharper colors but slower rendering.'
        )
        row_zoom.addWidget(self.spin_zoom)
        row_zoom.addStretch()
        lay_class.addLayout(row_zoom)

        # Auto sample resolution
        row_sample = QHBoxLayout()
        self.chk_auto_res = QCheckBox('Auto sample resolution from polygon size')
        self.chk_auto_res.setChecked(True)
        self.chk_auto_res.setToolTip(
            'Automatically compute pixel grid size based on polygon area and zoom level.\n'
            'Uncheck to set manually.'
        )
        row_sample.addWidget(self.chk_auto_res)
        lay_class.addLayout(row_sample)

        row_manual_res = QHBoxLayout()
        lbl_res = QLabel('  Manual resolution (px):')
        row_manual_res.addWidget(lbl_res)
        self.spin_sample = QSpinBox()
        self.spin_sample.setRange(64, 1024)
        self.spin_sample.setValue(256)
        self.spin_sample.setEnabled(False)
        self.spin_sample.setToolTip('Manual pixel grid size (width=height) for raster sampling.')
        row_manual_res.addWidget(self.spin_sample)
        row_manual_res.addStretch()
        lay_class.addLayout(row_manual_res)

        self.chk_auto_res.toggled.connect(lambda on: self.spin_sample.setEnabled(not on))

        root.addWidget(grp_class)

        # --- Mode selection ---
        grp_mode = QGroupBox('Operation mode')
        lay_mode = QVBoxLayout(grp_mode)

        self.mode_group = QButtonGroup(self)
        self.rb_tact   = QRadioButton('Tactical — camouflage (blend into terrain)')
        self.rb_rescue = QRadioButton('Rescue / SAR — anti-camouflage (maximum visibility)')
        self.rb_tact.setChecked(True)
        self.rb_tact.setToolTip('Generates camouflage patterns that blend with the terrain.')
        self.rb_rescue.setToolTip(
            'Generates high-visibility rescue patterns.\n'
            'For real-pattern mode: uses standard Hi-Vis colors (Safety Orange, Neon Yellow…)'
        )
        for rb in (self.rb_tact, self.rb_rescue):
            self.mode_group.addButton(rb)
            lay_mode.addWidget(rb)

        root.addWidget(grp_mode)

        # --- Internal classification ---
        grp_cls = QGroupBox('Internal zone classification')
        lay_cls = QVBoxLayout(grp_cls)

        self.chk_internal_cls = QCheckBox('Split polygon into terrain sub-zones (KMeans spatial)')
        self.chk_internal_cls.setChecked(True)
        self.chk_internal_cls.setToolTip(
            'Runs spatial KMeans on the raster pixels to detect terrain types\n'
            '(desert, forest, water, etc.) and assigns a separate pattern to each.'
        )
        lay_cls.addWidget(self.chk_internal_cls)

        row_autonz = QHBoxLayout()
        self.chk_auto_zones = QCheckBox('Auto-detect number of terrain sub-zones (elbow method)')
        self.chk_auto_zones.setChecked(True)
        self.chk_auto_zones.setToolTip(
            'Automatically finds the optimal number of terrain classes\n'
            'using the elbow method on KMeans inertia (tests 2–8 zones).'
        )
        row_autonz.addWidget(self.chk_auto_zones)
        lay_cls.addLayout(row_autonz)

        row_nz = QHBoxLayout()
        lbl_nz = QLabel('  Manual sub-zones:')
        row_nz.addWidget(lbl_nz)
        self.spin_zones = QSpinBox()
        self.spin_zones.setRange(2, 8)
        self.spin_zones.setValue(3)
        self.spin_zones.setEnabled(False)
        self.spin_zones.setToolTip('Manual number of terrain classes (used when auto is off).')
        row_nz.addWidget(self.spin_zones)
        row_nz.addStretch()
        lay_cls.addLayout(row_nz)
        self.chk_auto_zones.toggled.connect(lambda on: self.spin_zones.setEnabled(not on))

        root.addWidget(grp_cls)

        # --- Pattern type ---
        grp_pat = QGroupBox('Pattern source')
        lay_pat = QVBoxLayout(grp_pat)
        self.pat_group = QButtonGroup(self)
        self.rb_synth      = QRadioButton('Synthetic (per sub-zone, generated from terrain colors)')
        self.rb_real_zone  = QRadioButton('Real per sub-zone (best DB match per zone)')
        self.rb_real_poly  = QRadioButton('Real per polygon (one best DB match for whole polygon)')
        self.rb_synth.setChecked(True)
        self.rb_synth.setToolTip(
            'Generates Pixel/Spots/Heritage pattern per sub-zone from its dominant colors.\n'
            'Best spatial accuracy — each terrain type gets its own palette.'
        )
        self.rb_real_zone.setToolTip(
            'Finds the closest real camouflage from DB for each sub-zone separately.\n'
            'Sub-zones may get different real patterns.'
        )
        self.rb_real_poly.setToolTip(
            'Averages colors across the whole polygon, finds ONE best real pattern.\n'
            'More coherent result — the whole area uses one pattern.'
        )
        for rb in (self.rb_synth, self.rb_real_zone, self.rb_real_poly):
            self.pat_group.addButton(rb)
            lay_pat.addWidget(rb)

        # Biome coarseness for real-pattern modes
        row_biome = QHBoxLayout()
        lbl_biome = QLabel('  Biome coarseness (for real-pattern modes):')
        row_biome.addWidget(lbl_biome)
        self.spin_biome_k = QSpinBox()
        self.spin_biome_k.setRange(2, 6)
        self.spin_biome_k.setValue(3)
        self.spin_biome_k.setToolTip(
            'Number of color clusters used when computing dominant colors\n'
            'for real-pattern DB matching. Lower = more generalised match.'
        )
        row_biome.addWidget(self.spin_biome_k)
        row_biome.addStretch()
        lay_pat.addLayout(row_biome)

        # Enable biome_k only for real modes
        def _update_biome_k():
            self.spin_biome_k.setEnabled(
                self.rb_real_zone.isChecked() or self.rb_real_poly.isChecked()
            )
        self.rb_synth.toggled.connect(lambda _: _update_biome_k())
        self.rb_real_zone.toggled.connect(lambda _: _update_biome_k())
        self.rb_real_poly.toggled.connect(lambda _: _update_biome_k())
        _update_biome_k()

        root.addWidget(grp_pat)

        # --- Output options ---
        grp_out = QGroupBox('Output')
        lay_out = QVBoxLayout(grp_out)
        self.chk_add_layer = QCheckBox('Add result as raster layer to project')
        self.chk_add_layer.setChecked(True)
        self.chk_temp_layer = QCheckBox('Save as temporary layer (auto-deleted on QGIS close)')
        self.chk_temp_layer.setChecked(True)
        self.chk_temp_layer.setToolTip(
            'Saves GeoTIFF to system temp folder — no file locking issues.\n'
            'Uncheck to save to the output folder permanently.'
        )
        self.chk_save_report = QCheckBox('Save PNG report alongside raster')
        lay_out.addWidget(self.chk_add_layer)
        lay_out.addWidget(self.chk_temp_layer)
        lay_out.addWidget(self.chk_save_report)

        row_out_path = QHBoxLayout()
        row_out_path.addWidget(QLabel('Output folder:'))
        self.lbl_out_path = QLabel('<default: project folder>')
        self.lbl_out_path.setStyleSheet('color: gray; font-style: italic;')
        row_out_path.addWidget(self.lbl_out_path, 1)
        btn_browse = QPushButton('…')
        btn_browse.setFixedWidth(32)
        btn_browse.clicked.connect(self._browse_output)
        row_out_path.addWidget(btn_browse)
        lay_out.addLayout(row_out_path)
        self._output_folder = None

        root.addWidget(grp_out)

        root.addStretch(1)

        # --- Progress + Log + Buttons — fixed at bottom outside scroll ---
        bottom = QWidget()
        bot_layout = QVBoxLayout(bottom)
        bot_layout.setContentsMargins(10, 4, 10, 4)
        bot_layout.setSpacing(4)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        bot_layout.addWidget(self.progress)

        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setFixedHeight(90)
        self.log.setPlaceholderText('Processing log will appear here…')
        bot_layout.addWidget(self.log)

        row_btn = QHBoxLayout()
        self.btn_run = QPushButton('▶  Run CamoPicker')
        self.btn_run.setDefault(True)
        self.btn_run.clicked.connect(self.run_analysis)
        self.btn_cancel = QPushButton('Cancel')
        self.btn_cancel.setEnabled(False)
        self.btn_cancel.clicked.connect(self._cancel)
        btn_close = QPushButton('Close')
        btn_close.clicked.connect(self.close)
        row_btn.addWidget(self.btn_run)
        row_btn.addWidget(self.btn_cancel)
        row_btn.addStretch()
        row_btn.addWidget(btn_close)
        bot_layout.addLayout(row_btn)

        outer.addWidget(bottom)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _browse_output(self):
        from qgis.PyQt.QtWidgets import QFileDialog
        folder = QFileDialog.getExistingDirectory(
            self, 'Select output folder', os.path.expanduser('~')
        )
        if folder:
            self._output_folder = folder
            self.lbl_out_path.setText(folder)
            self.lbl_out_path.setStyleSheet('')

    def populate_layers(self):
        """Re-populate combo boxes from current QGIS project layers."""
        self.cb_polygon.clear()
        self.cb_raster.clear()

        project = QgsProject.instance()
        for lid, layer in project.mapLayers().items():
            if layer.type() == QgsMapLayer.VectorLayer:
                from qgis.core import QgsWkbTypes
                geom_type = layer.geometryType()
                if geom_type == QgsWkbTypes.PolygonGeometry:
                    self.cb_polygon.addItem(layer.name(), lid)
            elif layer.type() == QgsMapLayer.RasterLayer:
                self.cb_raster.addItem(layer.name(), lid)

        has_poly = self.cb_polygon.count() > 0
        has_rast = self.cb_raster.count() > 0
        self.btn_run.setEnabled(has_poly and has_rast)
        if not has_poly:
            self._log('⚠ No polygon layers found in project.')
        if not has_rast:
            self._log('⚠ No raster layers found in project.')

    def _log(self, msg: str):
        self.log.append(msg)
        QgsMessageLog.logMessage(msg, 'CamoPicker', Qgis.Info)

    def _mode_str(self) -> str:
        return '3' if self.rb_rescue.isChecked() else '2'

    # ------------------------------------------------------------------
    # Run / cancel
    # ------------------------------------------------------------------
    def run_analysis(self):
        project = QgsProject.instance()
        poly_id = self.cb_polygon.currentData()
        rast_id = self.cb_raster.currentData()
        if not poly_id or not rast_id:
            self._log('❌ Please select both a polygon and a raster layer.')
            return

        poly_layer = project.mapLayer(poly_id)
        rast_layer = project.mapLayer(rast_id)

        # Determine output folder
        out_folder = self._output_folder
        if not out_folder:
            proj_path = QgsProject.instance().absolutePath()
            out_folder = proj_path if proj_path else os.path.expanduser('~')

        params = {
            'polygon_layer': poly_layer,
            'selected_only': self.chk_selected_only.isChecked(),
            'raster_layer': rast_layer,
            'k_clusters': self.spin_k.value(),
            'sample_res': self.spin_sample.value(),
            'auto_res': self.chk_auto_res.isChecked(),
            'zoom': self.spin_zoom.value(),
            'mode': self._mode_str(),
            'output_folder': out_folder,
            'save_report': self.chk_save_report.isChecked(),
            'internal_cls': self.chk_internal_cls.isChecked(),
            'n_zones': self.spin_zones.value(),
            'auto_zones': self.chk_auto_zones.isChecked(),
            'temp_layer': self.chk_temp_layer.isChecked(),
            'pat_mode': ('synth' if self.rb_synth.isChecked() else
                         'real_poly' if self.rb_real_poly.isChecked() else
                         'real_zone'),
            'biome_k': self.spin_biome_k.value(),
        }

        self.btn_run.setEnabled(False)
        self.btn_cancel.setEnabled(True)
        self.progress.setValue(0)
        self.log.clear()
        self._log('🚀 Starting CamoPicker analysis…')

        # Run in background thread
        self.thread = QThread()
        self.worker = EngineWorker(params)
        self.worker.moveToThread(self.thread)

        self.thread.started.connect(self.worker.run)
        self.worker.progress.connect(self.progress.setValue)
        self.worker.log_msg.connect(self._log)
        self.worker.finished.connect(self._on_finished)
        self.worker.error.connect(self._on_error)
        self.worker.finished.connect(self.thread.quit)
        self.worker.error.connect(self.thread.quit)
        self.thread.finished.connect(self.thread.deleteLater)

        self.thread.start()

    def _cancel(self):
        if self.worker:
            self.worker.request_stop()
        self._log('⏹ Cancellation requested…')
        self.btn_cancel.setEnabled(False)

    def _on_finished(self, output_paths: dict):
        self._log('✅ Analysis complete!')
        if self.chk_add_layer.isChecked():
            self._load_output_layers(output_paths)
        self.progress.setValue(100)
        self.btn_run.setEnabled(True)
        self.btn_cancel.setEnabled(False)

    def _on_error(self, msg: str):
        self._log(f'❌ Error: {msg}')
        self.progress.setValue(0)
        self.btn_run.setEnabled(True)
        self.btn_cancel.setEnabled(False)

    def _load_output_layers(self, output_paths: dict):
        """Add generated GeoTIFF files as raster layers to the project."""
        project = QgsProject.instance()
        for display_name, tiff_path in output_paths.items():
            if not os.path.exists(tiff_path):
                self._log(f'  ⚠ File not found: {tiff_path}')
                continue
            layer = QgsRasterLayer(tiff_path, display_name)
            if layer.isValid():
                project.addMapLayer(layer)
                self._log(f'  📍 Added layer: {display_name}')
            else:
                self._log(f'  ⚠ Invalid raster: {tiff_path}')
