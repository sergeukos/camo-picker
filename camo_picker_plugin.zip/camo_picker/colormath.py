# -*- coding: utf-8 -*-
from __future__ import annotations
"""
colormath.py — pure numpy implementations of:
  - rgb2lab / lab2rgb  (sRGB ↔ CIE L*a*b*, D65)
  - deltaE_ciede2000   (CIEDE2000 color difference)
  - KMeans             (Lloyd's algorithm, k-means++)

Replaces scikit-image and scikit-learn entirely.
Only dependency: numpy (already in QGIS).
"""

import numpy as np

# ---------------------------------------------------------------------------
# sRGB ↔ CIE L*a*b*  (D65 illuminant)
# ---------------------------------------------------------------------------
_D65 = np.array([0.95047, 1.00000, 1.08883], dtype=np.float64)


def _srgb_to_linear(c):
    c = np.asarray(c, dtype=np.float64)
    return np.where(c <= 0.04045, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)


def _linear_to_srgb(c):
    c = np.asarray(c, dtype=np.float64)
    return np.where(c <= 0.0031308, 12.92 * c, 1.055 * c ** (1.0 / 2.4) - 0.055)


_M_RGB2XYZ = np.array([
    [0.4124564, 0.3575761, 0.1804375],
    [0.2126729, 0.7151522, 0.0721750],
    [0.0193339, 0.1191920, 0.9503041],
], dtype=np.float64)

_M_XYZ2RGB = np.linalg.inv(_M_RGB2XYZ)


def _f(t):
    delta = 6.0 / 29.0
    return np.where(t > delta**3, np.cbrt(t), t / (3 * delta**2) + 4.0 / 29.0)


def _finv(t):
    delta = 6.0 / 29.0
    return np.where(t > delta, t**3, 3 * delta**2 * (t - 4.0 / 29.0))


def rgb2lab(rgb_float):
    """
    rgb_float: (..., 3) float array in [0, 1]
    returns:   (..., 3) L*a*b* array
    """
    rgb = np.asarray(rgb_float, dtype=np.float64)
    shape = rgb.shape
    flat  = rgb.reshape(-1, 3)

    lin  = _srgb_to_linear(flat)
    xyz  = lin @ _M_RGB2XYZ.T / _D65          # normalise by D65
    fx   = _f(xyz)
    L    = 116.0 * fx[:, 1] - 16.0
    a    = 500.0 * (fx[:, 0] - fx[:, 1])
    b    = 200.0 * (fx[:, 1] - fx[:, 2])
    return np.stack([L, a, b], axis=-1).reshape(shape)


def lab2rgb(lab):
    """
    lab: (..., 3) L*a*b* array
    returns: (..., 3) float array in [0, 1], clipped
    """
    lab  = np.asarray(lab, dtype=np.float64)
    shape = lab.shape
    flat  = lab.reshape(-1, 3)

    L, a, b = flat[:, 0], flat[:, 1], flat[:, 2]
    fy = (L + 16.0) / 116.0
    fx = a / 500.0 + fy
    fz = fy - b / 200.0
    xyz = np.stack([_finv(fx), _finv(fy), _finv(fz)], axis=-1) * _D65
    lin = xyz @ _M_XYZ2RGB.T
    rgb = _linear_to_srgb(lin)
    return np.clip(rgb, 0.0, 1.0).reshape(shape)


# ---------------------------------------------------------------------------
# CIEDE2000 color difference
# ---------------------------------------------------------------------------
def deltaE_ciede2000(lab1, lab2):
    """
    lab1, lab2: (..., 3) L*a*b* arrays (broadcast-compatible)
    returns: (...) array of CIEDE2000 distances
    """
    lab1 = np.asarray(lab1, dtype=np.float64)
    lab2 = np.asarray(lab2, dtype=np.float64)

    L1, a1, b1 = lab1[..., 0], lab1[..., 1], lab1[..., 2]
    L2, a2, b2 = lab2[..., 0], lab2[..., 1], lab2[..., 2]

    # Step 1
    C1 = np.sqrt(a1**2 + b1**2)
    C2 = np.sqrt(a2**2 + b2**2)
    Cb = (C1 + C2) / 2.0
    Cb7 = Cb**7
    G  = 0.5 * (1.0 - np.sqrt(Cb7 / (Cb7 + 25.0**7)))
    a1p = a1 * (1.0 + G)
    a2p = a2 * (1.0 + G)
    C1p = np.sqrt(a1p**2 + b1**2)
    C2p = np.sqrt(a2p**2 + b2**2)

    h1p = np.degrees(np.arctan2(b1, a1p)) % 360.0
    h2p = np.degrees(np.arctan2(b2, a2p)) % 360.0

    # Step 2
    dLp = L2 - L1
    dCp = C2p - C1p
    dhp = np.where(
        C1p * C2p == 0, 0.0,
        np.where(np.abs(h2p - h1p) <= 180, h2p - h1p,
                 np.where(h2p - h1p > 180, h2p - h1p - 360, h2p - h1p + 360))
    )
    dHp = 2.0 * np.sqrt(C1p * C2p) * np.sin(np.radians(dhp / 2.0))

    # Step 3
    Lbp = (L1 + L2) / 2.0
    Cbp = (C1p + C2p) / 2.0
    hbp = np.where(
        C1p * C2p == 0, h1p + h2p,
        np.where(np.abs(h1p - h2p) <= 180, (h1p + h2p) / 2.0,
                 np.where(h1p + h2p < 360, (h1p + h2p + 360) / 2.0,
                          (h1p + h2p - 360) / 2.0))
    )

    T = (1.0
         - 0.17 * np.cos(np.radians(hbp - 30))
         + 0.24 * np.cos(np.radians(2 * hbp))
         + 0.32 * np.cos(np.radians(3 * hbp + 6))
         - 0.20 * np.cos(np.radians(4 * hbp - 63)))

    SL = 1.0 + 0.015 * (Lbp - 50)**2 / np.sqrt(20 + (Lbp - 50)**2)
    SC = 1.0 + 0.045 * Cbp
    SH = 1.0 + 0.015 * Cbp * T

    Cbp7 = Cbp**7
    RC  = 2.0 * np.sqrt(Cbp7 / (Cbp7 + 25.0**7))
    d_theta = 30.0 * np.exp(-((hbp - 275.0) / 25.0)**2)
    RT  = -np.sin(np.radians(2.0 * d_theta)) * RC

    kL = kC = kH = 1.0
    return np.sqrt(
        (dLp / (kL * SL))**2 +
        (dCp / (kC * SC))**2 +
        (dHp / (kH * SH))**2 +
        RT * (dCp / (kC * SC)) * (dHp / (kH * SH))
    )


# ---------------------------------------------------------------------------
# KMeans  (k-means++ init + Lloyd iterations)
# ---------------------------------------------------------------------------
class KMeans:
    def __init__(self, n_clusters=8, n_init='auto', max_iter=300, random_state=None):
        self.n_clusters   = n_clusters
        self.n_init       = 3 if n_init == 'auto' else int(n_init)
        self.max_iter     = max_iter
        self.random_state = random_state
        self.cluster_centers_ = None
        self.labels_          = None

    def fit(self, X):
        X   = np.asarray(X, dtype=np.float64)
        rng = np.random.RandomState(self.random_state)
        best_inertia  = np.inf
        best_centers  = None
        best_labels   = None

        for _ in range(self.n_init):
            centers = self._init_plusplus(X, rng)
            labels, centers = self._lloyd(X, centers)
            inertia = float(np.sum((X - centers[labels])**2))
            if inertia < best_inertia:
                best_inertia = inertia
                best_centers = centers
                best_labels  = labels

        self.cluster_centers_ = best_centers
        self.labels_          = best_labels
        return self

    def _init_plusplus(self, X, rng):
        idx     = rng.randint(0, len(X))
        centers = [X[idx]]
        for _ in range(1, self.n_clusters):
            D2 = np.min(
                np.stack([np.sum((X - c)**2, axis=1) for c in centers], axis=1),
                axis=1
            )
            total = D2.sum()
            if total == 0 or not np.isfinite(total):
                # All points identical — pick randomly
                idx = rng.randint(0, len(X))
            else:
                probs = D2 / total
                # Fix any residual NaN/negative from float precision
                probs = np.where(np.isfinite(probs) & (probs >= 0), probs, 0.0)
                s = probs.sum()
                probs = np.ones(len(X)) / len(X) if s == 0 else probs / s
                idx = rng.choice(len(X), p=probs)
            centers.append(X[idx])
        return np.array(centers)

    def _lloyd(self, X, centers):
        for _ in range(self.max_iter):
            # Assignment
            dists  = np.stack([np.sum((X - c)**2, axis=1) for c in centers], axis=1)
            labels = np.argmin(dists, axis=1)
            # Update
            new_centers = np.array([
                X[labels == k].mean(axis=0) if np.any(labels == k) else centers[k]
                for k in range(self.n_clusters)
            ])
            if np.allclose(new_centers, centers, atol=1e-6):
                break
            centers = new_centers
        return labels, centers
