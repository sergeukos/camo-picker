# -*- coding: utf-8 -*-
"""
CamoPicker QGIS Plugin — plugin.py
Main plugin class: registers toolbar button, launches dialog.
"""

import os
from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsProject

from .camo_dialog import CamoPickerDialog


class CamoPickerPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.toolbar = None
        self.dialog = None

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, 'icons', 'camo_icon.png')
        self.action = QAction(
            QIcon(icon_path),
            'CamoPicker — Tactical Pattern Generator',
            self.iface.mainWindow()
        )
        self.action.setToolTip(
            'Analyze terrain and generate camouflage patterns per zone'
        )
        self.action.triggered.connect(self.run)

        # Add to Plugins toolbar
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToRasterMenu('&CamoPicker', self.action)

    def unload(self):
        self.iface.removePluginRasterMenu('&CamoPicker', self.action)
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        if self.dialog is None:
            self.dialog = CamoPickerDialog(self.iface, self.iface.mainWindow())
        self.dialog.populate_layers()
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()
