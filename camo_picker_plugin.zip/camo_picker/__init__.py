# -*- coding: utf-8 -*-
import sys
import io

# QGIS on Windows sets sys.stderr = None during plugin load,
# which causes numpy/sklearn to crash on import.
# Patch it before any heavy imports happen.
if sys.stderr is None:
    sys.stderr = io.StringIO()
if sys.stdout is None:
    sys.stdout = io.StringIO()


def classFactory(iface):
    from .plugin import CamoPickerPlugin
    return CamoPickerPlugin(iface)
