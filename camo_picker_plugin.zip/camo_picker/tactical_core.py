# -*- coding: utf-8 -*-
"""
CamoPicker QGIS Plugin — tactical_core.py

Adapted from trololo_2_8.py (Tactical Engine V12.1 "Luminance Spark").
Changes vs original:
  - TacticalCoreV12_1.__init__ accepts headless=True (skips session setup when not needed)
  - main() removed (entry point is engine_worker.py)
  - webbrowser.open() removed from ReporterV12.draw_all()
  - ReporterV12.draw_all() accepts optional out_path parameter
  - tqdm replaced with simple print() / pyqtSignal-compatible no-op
  - All pattern generation methods preserved verbatim.
"""

# Heavy scientific libraries are imported LAZILY (inside methods/functions).
# This prevents the numpy/sys.stderr crash on QGIS plugin load on Windows
# where sys.stderr is None at import time.
# Only stdlib modules at module level:
import math
import re
import time
from io import BytesIO
from collections import Counter
from concurrent.futures import ThreadPoolExecutor

# ---------------------------------------------------------------------------
# Lazy-import state
# ---------------------------------------------------------------------------
_lazy_done = False
_np = _Image = _ImageDraw = _ImageFilter = None
_KMeans = _skcolor = _requests = _mercantile = None
_HTTPAdapter = _Retry = None


def _lazy_imports():
    global _lazy_done, _np, _Image, _ImageDraw, _ImageFilter
    global _KMeans, _skcolor, _requests, _mercantile, _HTTPAdapter, _Retry
    if _lazy_done:
        return
    import numpy as _n
    _np = _n
    from PIL import Image as _Im, ImageDraw as _Id, ImageFilter as _If
    _Image, _ImageDraw, _ImageFilter = _Im, _Id, _If
    from .colormath import KMeans as _KM, rgb2lab as _r2l, lab2rgb as _l2r, deltaE_ciede2000 as _dE
    _KMeans  = _KM
    # Use a SimpleNamespace so _skcolor.rgb2lab(x) dispatches correctly without self
    import types as _types
    _skcolor = _types.SimpleNamespace(rgb2lab=_r2l, lab2rgb=_l2r, deltaE_ciede2000=_dE)
    import requests as _req
    _requests = _req
    try:
        import mercantile as _merc
        _mercantile = _merc
    except ImportError:
        _mercantile = None
    from requests.adapters import HTTPAdapter as _HA
    _HTTPAdapter = _HA
    from urllib3.util.retry import Retry as _R
    _Retry = _R
    _lazy_done = True

# ---------------------------------------------------------------------------
# Constants (unchanged from original)
# ---------------------------------------------------------------------------
MATRIX_SIZE = 96
GITHUB_BASE_URL = "https://raw.githubusercontent.com/sergeukos/camo-picker/main/CamoDatabase/"
GITHUB_METADATA_URL = GITHUB_BASE_URL + "camo_metadata.json"

HIGH_VIS_STANDARDS = {
    "Safety Orange (SOS)": [255, 79, 0],
    "Neon Lemon (Hi-Vis)": [212, 255, 0],
    "Electric Blue": [0, 100, 255],
    "Emergency Magenta": [255, 0, 144],
    "Signal White": [255, 255, 255],
    "Solar Yellow": [255, 210, 0]
}


def _noop_tqdm(iterable, **kwargs):
    """Drop-in tqdm replacement — just iterates silently."""
    return iterable


# ---------------------------------------------------------------------------
# Engine (preserved verbatim, minimal surgical changes marked with # QGIS)
# ---------------------------------------------------------------------------
class TacticalCoreV12_1:
    def __init__(self, headless: bool = False):
        """
        headless=True: skip HTTP session init (used when worker is created
        before QThread starts; session is created lazily on first use).
        """
        _lazy_imports()  # ensure heavy deps loaded before any use
        self.db: dict = {}
        self._headless = headless
        self._session = None

    @property
    def session(self):
        """Lazy HTTP session with retries."""
        if self._session is None:
            self._session = _requests.Session()
            retries = _Retry(
                total=20, backoff_factor=1,
                status_forcelist=[429, 500, 502, 503, 504]
            )
            self._session.mount(
                'https://',
                _HTTPAdapter(
                    max_retries=retries,
                    pool_connections=50,
                    pool_maxsize=50
                )
            )
        return self._session

    # -----------------------------------------------------------------------
    # Pattern generation — preserved verbatim from trololo_2_8.py
    # -----------------------------------------------------------------------
    def _apply_optical_pivot(self, doms, avg_l, mode='TACTICAL'):
        pivoted = []
        has_greenery = any(d[0][1] > d[0][0] and d[0][1] > d[0][2] for d in doms)
        for i, (rgb, weight) in enumerate(doms):
            lab = _skcolor.rgb2lab(
                _np.array([[rgb]], dtype=_np.float32) / 255.0
            ).reshape(3)
            if mode == 'TACTICAL':
                lab[0] = _np.clip(lab[0] + (i * 10 - 15), 10, 95)
                if has_greenery and lab[0] > 85:
                    lab[0] = 85
                lab[1:] *= 1.3
            else:
                lab[0] = 95 if lab[0] < 50 else 15
            new_rgb = (
                _skcolor.lab2rgb(lab.reshape(1, 1, 3))[0, 0] * 255
            ).astype(_np.uint8).tolist()
            pivoted.append([new_rgb, weight])
        return pivoted

    def _draw_seamless(self, draw, shape, coords, fill):
        x1, y1, x2, y2 = coords
        for ox in [0, -MATRIX_SIZE, MATRIX_SIZE]:
            for oy in [0, -MATRIX_SIZE, MATRIX_SIZE]:
                if shape == 'rect':
                    draw.rectangle(
                        [x1 + ox, y1 + oy, x2 + ox, y2 + oy], fill=fill
                    )
                elif shape == 'ellipse':
                    draw.ellipse(
                        [x1 + ox, y1 + oy, x2 + ox, y2 + oy], fill=fill
                    )

    def generate_pixel_apex(self, doms, entropy):
        doms.sort(key=lambda x: x[1], reverse=True)
        canvas = _Image.new('RGB', (MATRIX_SIZE, MATRIX_SIZE),
                           tuple(map(int, doms[0][0])))
        draw = _ImageDraw.Draw(canvas)
        c2 = tuple(map(int, doms[1][0]))
        for _ in range(_np.random.randint(6, 10)):
            x, y = (_np.random.randint(0, MATRIX_SIZE),
                    _np.random.randint(0, MATRIX_SIZE))
            bw, bh = (_np.random.randint(25, 45),
                      _np.random.randint(15, 30))
            self._draw_seamless(draw, 'rect',
                                [x, y, x + bw, y + bh], fill=c2)
        others = doms[1:5]
        others.sort(
            key=lambda x: _skcolor.rgb2lab(
                _np.array([[x[0]]], dtype=_np.float32) / 255.0
            )[0, 0, 0]
        )
        for rgb, weight in others:
            c = tuple(map(int, rgb))
            lab_l = _skcolor.rgb2lab(
                _np.array([[rgb]], dtype=_np.float32) / 255.0
            )[0, 0, 0]
            is_spark = lab_l > 58
            boost = 2.8 if is_spark else 1.0
            num_clusters = int(_np.clip((weight / 4) * boost, 3, 14))
            for _ in range(num_clusters):
                cx, cy = (_np.random.randint(0, MATRIX_SIZE),
                          _np.random.randint(0, MATRIX_SIZE))
                grain_w = 4 if is_spark else (8 if entropy < 18 else 4)
                grain_h = 2 if is_spark else (4 if entropy < 18 else 2)
                for _ in range(_np.random.randint(8, 18)):
                    offset_x = (
                        _np.random.randint(-14, 14) // grain_w
                    ) * grain_w
                    offset_y = (
                        _np.random.randint(-10, 10) // grain_h
                    ) * grain_h
                    px, py = cx + offset_x, cy + offset_y
                    self._draw_seamless(
                        draw, 'rect',
                        [px, py, px + grain_w, py + grain_h], fill=c
                    )
        return _np.array(canvas)

    def generate_spots_850(self, doms):
        doms.sort(key=lambda x: x[1], reverse=True)
        all_labs = [
            _skcolor.rgb2lab(
                _np.array([[d[0]]], dtype=_np.float32) / 255.0
            )[0, 0, 0]
            for d in doms
        ]
        avg_env_l = _np.mean(all_labs)
        canvas = _Image.new('RGB', (MATRIX_SIZE, MATRIX_SIZE),
                           tuple(map(int, doms[0][0])))
        for rgb, weight in doms[1:]:
            lab = _skcolor.rgb2lab(
                _np.array([[rgb]], dtype=_np.float32) / 255.0
            ).reshape(3)
            if lab[0] > avg_env_l + 15:
                lab[0] = avg_env_l + 15
            lab[1:] *= 0.8
            c_corrected = (
                _skcolor.lab2rgb(lab.reshape(1, 1, 3))[0, 0] * 255
            ).astype(_np.uint8).tolist()
            c = tuple(map(int, c_corrected))
            mask = _Image.new('L', (MATRIX_SIZE, MATRIX_SIZE), 0)
            d = _ImageDraw.Draw(mask)
            num_seeds = (int(weight * 1.8) if weight > 7
                         else int(weight * 8))
            for _ in range(max(1, num_seeds // 2)):
                rx = _np.random.randint(0, MATRIX_SIZE)
                ry = _np.random.randint(0, MATRIX_SIZE)
                for _ in range(_np.random.randint(2, 5)):
                    ox = rx + _np.random.randint(-12, 12)
                    oy = ry + _np.random.randint(-12, 12)
                    size = (_np.random.randint(20, 45) if weight > 15
                            else _np.random.randint(5, 15))
                    self._draw_seamless(
                        d, 'ellipse',
                        [ox - size // 2, oy - size // 2,
                         ox + size // 2, oy + size // 2],
                        fill=255
                    )
            mask = mask.filter(
                _ImageFilter.GaussianBlur(
                    radius=_np.random.uniform(2.5, 4.0)
                )
            ).point(lambda p: 255 if p > 135 else 0)
            canvas.paste(
                _Image.new('RGB', (MATRIX_SIZE, MATRIX_SIZE), c),
                (0, 0), mask
            )
        return _np.array(canvas)

    def generate_heritage_woodland(self, doms):
        doms.sort(key=lambda x: x[1], reverse=True)
        canvas = _Image.new('RGB', (MATRIX_SIZE, MATRIX_SIZE),
                           tuple(map(int, doms[0][0])))
        for rgb, weight in doms[1:]:
            c = tuple(map(int, rgb))
            mask = _Image.new('L', (MATRIX_SIZE, MATRIX_SIZE), 0)
            d = _ImageDraw.Draw(mask)
            num_blobs = max(2, int(weight * 0.6))
            for _ in range(num_blobs):
                cx = _np.random.randint(10, MATRIX_SIZE - 10)
                cy = _np.random.randint(10, MATRIX_SIZE - 10)
                for _ in range(_np.random.randint(3, 7)):
                    ox = cx + _np.random.randint(-20, 20)
                    oy = cy + _np.random.randint(-20, 20)
                    w = _np.random.randint(8, 28)
                    h = _np.random.randint(6, 20)
                    self._draw_seamless(
                        d, 'ellipse',
                        [ox - w, oy - h, ox + w, oy + h],
                        fill=255
                    )
            mask = mask.filter(
                _ImageFilter.GaussianBlur(radius=3.5)
            ).point(lambda p: 255 if p > 120 else 0)
            canvas.paste(
                _Image.new('RGB', (MATRIX_SIZE, MATRIX_SIZE), c),
                (0, 0), mask
            )
        return _np.array(canvas)

    def generate_rescue_dazzle(self, env_doms):
        avg_rgb = _np.mean([d[0] for d in env_doms], axis=0)
        lab_bg = _skcolor.rgb2lab(
            _np.array([[avg_rgb]], dtype=_np.float32) / 255.0
        ).reshape(3)
        best_n, max_de = "Signal White", 0
        for n, rgb in HIGH_VIS_STANDARDS.items():
            de = _skcolor.deltaE_ciede2000(
                lab_bg,
                _skcolor.rgb2lab(
                    _np.array([[rgb]], dtype=_np.float32) / 255.0
                ).reshape(3)
            )
            if de > max_de:
                max_de, best_n = de, n
        sig_c = tuple(HIGH_VIS_STANDARDS[best_n])
        canvas = _Image.new('RGB', (MATRIX_SIZE, MATRIX_SIZE), sig_c)
        d = _ImageDraw.Draw(canvas)
        white = (255, 255, 255) if best_n != "Signal White" else (0, 0, 0)
        for size in range(MATRIX_SIZE, 0, -18):
            cf = white if (size // 18) % 2 == 0 else sig_c
            d.regular_polygon(
                (MATRIX_SIZE // 2, MATRIX_SIZE // 2, size // 1.1),
                4, rotation=45, fill=cf
            )
        return _np.array(canvas)

    # -----------------------------------------------------------------------
    # Terrain fetch (used only in standalone mode, not in QGIS plugin)
    # -----------------------------------------------------------------------
    def get_terrain(self, lat, lon, radius_m):
        z = int(_np.clip(18 - math.log2(radius_m / 400), 10, 19))
        while z > 0:
            m_deg = 111320 * math.cos(math.radians(lat))
            d = radius_m / m_deg
            ul = _mercantile.tile(lon - d, lat + d, z)
            lr = _mercantile.tile(lon + d, lat - d, z)
            x_r = range(ul.x, lr.x + 1)
            y_r = range(ul.y, lr.y + 1)
            if len(x_r) * len(y_r) > 49:
                z -= 1
                continue
            canvas = _Image.new('RGB', (len(x_r) * 256, len(y_r) * 256))
            tile_hashes = []

            def fetch(tx, ty):
                try:
                    r = self.session.get(
                        f"https://server.arcgisonline.com/ArcGIS/rest/services/"
                        f"World_Imagery/MapServer/tile/{z}/{ty}/{tx}",
                        timeout=10
                    )
                    return _Image.open(BytesIO(r.content))
                except Exception:
                    return _Image.new('RGB', (256, 256), (60, 65, 60))

            with ThreadPoolExecutor(max_workers=25) as ex:
                tasks = [
                    (i, j, tx, ty)
                    for i, tx in enumerate(x_r)
                    for j, ty in enumerate(y_r)
                ]
                for i, j, tx, ty in tasks:
                    tile_img = fetch(tx, ty)
                    canvas.paste(tile_img, (i * 256, j * 256))
                    tile_hashes.append(hash(tile_img.tobytes()))

            if len(set(tile_hashes)) <= 1 and len(tile_hashes) > 1:
                z -= 1
                continue
            else:
                break

        pix = _np.array(canvas.resize((150, 150))).reshape(-1, 3)
        km = _KMeans(n_clusters=6, n_init='auto').fit(pix)
        doms = [
            [km.cluster_centers_[i].tolist(),
             (Counter(km.labels_)[i] / 22500) * 100]
            for i in range(6)
        ]
        avg_l = _np.mean([
            _skcolor.rgb2lab(
                _np.array([[d[0]]], dtype=_np.float32) / 255.0
            ).reshape(3)[0]
            for d in doms
        ])
        return doms, canvas, avg_l, _np.std(pix)

    # ------------------------------------------------------------------
    # Попиксельное сравнение синтетиков с реальным паттерном из БД
    # ------------------------------------------------------------------

    def _load_db_image(self, camo_entry: dict):
        """
        Загружает реальное изображение паттерна из БД.
        Возвращает np.ndarray (MATRIX_SIZE x MATRIX_SIZE x 3) uint8
        или None при ошибке.
        Результат кэшируется в camo_entry['IMG'] чтобы не качать дважды.
        """
        _lazy_imports()
        if 'IMG' in camo_entry:
            return camo_entry['IMG']
        try:
            url = camo_entry.get('PATH', '')
            if not url:
                return None
            resp = self.session.get(url, timeout=10)
            img = _Image.open(BytesIO(resp.content)).convert('RGB')
            img = img.resize((MATRIX_SIZE, MATRIX_SIZE), _Image.LANCZOS)
            arr = _np.array(img, dtype=_np.uint8)
            camo_entry['IMG'] = arr   # кэш
            return arr
        except Exception:
            return None

    def match_synth_to_db(self, synth_mats: dict, camo_entry: dict, avg_l: float):
        """
        Сравнивает каждый синтетический паттерн (Pixel, Spots, Heritage)
        с реальным изображением из БД попиксельно в Lab-пространстве.

        Возвращает:
            best_de    — минимальный средний Delta-E среди трёх типов
            best_type  — тип синтетика с лучшим совпадением ('Pixel'/'Spots'/'Heritage')
            l_diff     — разница яркостей
            verdict    — 'MATCH' / 'GLOWING' / 'BLACK HOLE'
            per_type   — {type: de} для отладки
        """
        _lazy_imports()
        real_img = self._load_db_image(camo_entry)
        if real_img is None:
            # Фоллбэк: сравниваем по доминантному цвету
            c_rgb = camo_entry['DOMINANTS'][0][0]
            real_img = _np.full(
                (MATRIX_SIZE, MATRIX_SIZE, 3), c_rgb, dtype=_np.uint8
            )

        lab_real = _skcolor.rgb2lab(
            real_img.astype(_np.float32) / 255.0
        )

        per_type = {}
        best_de = float('inf')
        best_type = 'Spots'

        for synth_name, synth_arr in synth_mats.items():
            if synth_name == 'Rescue':
                continue   # rescue сравниваем отдельно
            lab_synth = _skcolor.rgb2lab(
                synth_arr.astype(_np.float32) / 255.0
            )
            de = float(_np.mean(_skcolor.deltaE_ciede2000(lab_real, lab_synth)))
            per_type[synth_name] = de
            if de < best_de:
                best_de = de
                best_type = synth_name

        # Яркостная метрика: средняя L реального паттерна vs avg_l зоны
        real_avg_l = float(_np.mean(lab_real[:, :, 0]))
        l_diff = real_avg_l - avg_l
        verdict = (
            "MATCH"      if -20 < l_diff < 15 else
            "GLOWING"    if l_diff > 15       else
            "BLACK HOLE"
        )
        return best_de, best_type, l_diff, verdict, per_type

    def rank_db_for_zone(
        self,
        synth_mats: dict,
        avg_l: float,
        mode: str = 'T',
        progress_cb=None
    ) -> list:
        """
        Ранжирует всю БД по совпадению с синтетическими паттернами зоны.

        Возвращает список кортежей:
          (camo_name, best_de, best_type, l_diff, verdict, path, per_type)
        отсортированных по best_de (лучший → первый).

        progress_cb(done, total) — опциональный колбэк прогресса.
        """
        _lazy_imports()
        results = []
        entries = list(self.db.items())
        total = len(entries)

        def _score_one(item):
            name, entry = item
            best_de, best_type, l_diff, verdict, per_type = self.match_synth_to_db(
                synth_mats, entry, avg_l
            )
            return (name, best_de, best_type, l_diff, verdict,
                    entry.get('PATH', ''), per_type)

        with ThreadPoolExecutor(max_workers=8) as ex:
            futures = {ex.submit(_score_one, item): i
                       for i, item in enumerate(entries)}
            done = 0
            for fut in futures:
                try:
                    results.append(fut.result())
                except Exception:
                    pass
                done += 1
                if progress_cb:
                    progress_cb(done, total)

        results.sort(key=lambda x: x[1])   # по Delta-E, меньше = лучше
        return results


    def rank_db_direct(self, doms: list, avg_l: float, progress_cb=None) -> list:
        """
        Прямое сравнение доминантных цветов зоны с паттернами БД.
        Не использует синтетик как посредника — сравниваем гистограммы
        доминантных цветов через взвешенный Delta-E.

        Алгоритм:
          Для каждого паттерна в БД:
            - Берём его DOMINANTS (4 цвета × вес)
            - Берём доминанты зоны (k цветов × вес)
            - Считаем Earth Mover's Distance (аппрокс.) через взвешенный Delta-E
            - Яркостный штраф: если avg_L паттерна далеко от avg_L зоны

        Возвращает список (name, score, l_diff, verdict, path),
        отсортированный по score (меньше = лучше).
        """
        _lazy_imports()

        # Подготовим Lab-представление доминант зоны с весами
        zone_labs = []
        zone_weights = []
        for rgb, w in doms:
            lab = _skcolor.rgb2lab(
                _np.array([[rgb]], dtype=_np.float32) / 255.0
            ).reshape(3)
            zone_labs.append(lab)
            zone_weights.append(w / 100.0)
        zone_labs    = _np.array(zone_labs)      # (k, 3)
        zone_weights = _np.array(zone_weights)   # (k,)
        zone_weights /= zone_weights.sum()

        results = []
        entries = list(self.db.items())
        total   = len(entries)

        for i, (name, entry) in enumerate(entries):
            if progress_cb:
                progress_cb(i, total)

            db_doms = entry.get('DOMINANTS', [])
            if not db_doms:
                continue

            # Lab + weights для паттерна БД
            db_labs    = []
            db_weights = []
            for rgb, w in db_doms:
                lab = _skcolor.rgb2lab(
                    _np.array([[rgb]], dtype=_np.float32) / 255.0
                ).reshape(3)
                db_labs.append(lab)
                db_weights.append(w / 100.0)
            db_labs    = _np.array(db_labs)
            db_weights = _np.array(db_weights)
            db_weights /= db_weights.sum()

            # Взвешенный Delta-E: для каждой доминанты зоны —
            # минимальный Delta-E среди доминант паттерна, взвешенный по весу зоны
            score = 0.0
            for zlab, zw in zip(zone_labs, zone_weights):
                des = _np.array([
                    float(_skcolor.deltaE_ciede2000(zlab, dlab))
                    for dlab in db_labs
                ])
                # Взвешенная сумма по БД (мягкий min через softmin)
                min_de = float(_np.min(des))
                score += zw * min_de

            # Яркостный штраф: avg_L паттерна vs avg_L зоны
            db_avg_l  = float(_np.mean([
                _skcolor.rgb2lab(_np.array([[rgb]], dtype=_np.float32)/255.0)[0,0,0]
                for rgb, _ in db_doms
            ]))
            l_diff  = db_avg_l - avg_l
            verdict = (
                "MATCH"      if -20 < l_diff < 15 else
                "GLOWING"    if l_diff >  15       else
                "BLACK HOLE"
            )
            # Штрафуем яркостное несовпадение
            l_penalty = max(0.0, abs(l_diff) - 15) * 0.5
            score += l_penalty

            results.append((
                name, round(score, 3), round(l_diff, 1), verdict,
                entry.get('PATH', '')
            ))

        results.sort(key=lambda x: x[1])
        return results

    def analyze_camo_irl(self, env, camo_data, avg_l, mode='T'):
        """
        Оставлен для обратной совместимости с ReporterV12.
        Использует попиксельное сравнение если доступно изображение,
        иначе — фоллбэк по доминантному цвету.
        """
        _lazy_imports()
        if mode == 'R':
            # Rescue: сравниваем среднюю яркость с High-Vis стандартом
            c_rgb = camo_data if isinstance(camo_data, list) else camo_data['DOMINANTS'][0][0]
            lab_ref_bg = _skcolor.rgb2lab(
                _np.array([[_np.mean([d[0] for d in env], axis=0)]],
                          dtype=_np.float32) / 255.0
            ).reshape(3)
            lab_sig = _skcolor.rgb2lab(
                _np.array([[c_rgb]], dtype=_np.float32) / 255.0
            ).reshape(3)
            de = float(_skcolor.deltaE_ciede2000(lab_ref_bg, lab_sig))
            l_diff = lab_sig[0] - avg_l
            return de, l_diff, "SIGNAL"

        # Tactical: попиксельное через match_synth_to_db если есть IMG
        if isinstance(camo_data, dict) and 'IMG' in camo_data:
            synth = {'Spots': self.generate_spots_850(list(env))}
            best_de, _, l_diff, verdict, _ = self.match_synth_to_db(
                synth, camo_data, avg_l
            )
            return best_de, l_diff, verdict

        # Фоллбэк (данные без изображения)
        c_rgb = (camo_data if isinstance(camo_data, list)
                 else camo_data['DOMINANTS'][0][0])
        ref_spots = self.generate_spots_850(list(env))
        lab_ref = _skcolor.rgb2lab(_np.array(ref_spots, dtype=_np.float32) / 255.0)
        lab_camo = _skcolor.rgb2lab(
            _np.full((MATRIX_SIZE, MATRIX_SIZE, 3), c_rgb, dtype=_np.float32) / 255.0
        )
        de = float(_np.mean(_skcolor.deltaE_ciede2000(lab_ref, lab_camo)))
        l_diff = float(lab_camo[0, 0, 0]) - avg_l
        verdict = "MATCH" if -20 < l_diff < 15 else ("GLOWING" if l_diff > 15 else "BLACK HOLE")
        return de, l_diff, verdict

    def load_db(self, cache_dir: str = None):
        """
        Load camouflage DB from GitHub with local disk cache.
        Falls back to cache when offline. Raises ConnectionError if both fail.
        """
        _lazy_imports()
        import os, json as _json, hashlib

        if cache_dir is None:
            import tempfile
            cache_dir = os.path.join(tempfile.gettempdir(), 'camo_picker_db')
        os.makedirs(cache_dir, exist_ok=True)
        meta_cache = os.path.join(cache_dir, 'camo_metadata.json')

        # Try to fetch fresh metadata (fast timeout — fails in ~3s if offline)
        meta = None
        try:
            resp = self.session.get(GITHUB_METADATA_URL, timeout=self._TIMEOUT)
            resp.raise_for_status()
            meta = resp.json()
            with open(meta_cache, 'w') as f:
                _json.dump(meta, f)
        except Exception as e:
            if os.path.exists(meta_cache):
                with open(meta_cache) as f:
                    meta = _json.load(f)
                self._offline_mode = True
            else:
                raise ConnectionError(f'No internet and no local cache ({e})')

        def proc(n, p):
            img_cache = os.path.join(
                cache_dir, hashlib.md5(n.encode()).hexdigest() + '.png'
            )
            try:
                if os.path.exists(img_cache):
                    img = _Image.open(img_cache).convert('RGB')
                else:
                    resp = self.session.get(
                        GITHUB_BASE_URL + n, timeout=self._TIMEOUT
                    )
                    resp.raise_for_status()
                    img = _Image.open(BytesIO(resp.content)).convert('RGB')
                    img.save(img_cache)
                img = img.resize((64, 64))
                pix = _np.asarray(img).reshape(-1, 3).astype(float)
                km  = _KMeans(n_clusters=4, n_init='auto').fit(pix)
                p.update({
                    'DOMINANTS': [
                        [km.cluster_centers_[i].tolist(), 25]
                        for i in range(4)
                    ],
                    'PATH': GITHUB_BASE_URL + n
                })
                return n, p
            except Exception:
                return None

        with ThreadPoolExecutor(max_workers=10) as ex:
            results = list(ex.map(lambda x: proc(*x), meta.items()))
        self.db = {r[0]: r[1] for r in results if r}


# ---------------------------------------------------------------------------
# Reporter (adapted: webbrowser removed, out_path param added)
# ---------------------------------------------------------------------------
class ReporterV12:
    def draw_all(self, map_img, avg_l, mats, ranks, mode_idx,
                 out_path: str = 'output_v12.png'):
        canvas = _Image.new('RGB', (1900, 2100), (10, 12, 14))
        draw = _ImageDraw.Draw(canvas)
        draw.text(
            (50, 20),
            f"TACTICAL ENGINE V12.1 | LUMINANCE SPARK | LIGHT: {avg_l:.1f}",
            fill=(0, 255, 180)
        )
        canvas.paste(map_img.resize((1000, 1000)), (50, 80))

        tact_list = ["Pixel", "Spots", "Heritage"]
        for i, name in enumerate(tact_list):
            if name in mats:
                x = 1100 + (i * 260)
                canvas.paste(
                    _Image.fromarray(mats[name]).resize(
                        (245, 245), _Image.NEAREST
                    ),
                    (x, 110)
                )
                draw.rectangle(
                    [x, 110, x + 245, 110 + 245],
                    outline=(0, 255, 150), width=2
                )
                draw.text((x, 80), name.upper(), fill=(0, 255, 180))

        t_ranks = [r for r in ranks if r[4] is not None]
        for i, (name, de, dl, v, p) in enumerate(t_ranks[:7]):
            ry = 410 + (i * 115)
            try:
                canvas.paste(
                    _Image.open(
                        BytesIO(_requests.get(p, timeout=5).content)
                    ).convert('RGB').resize((90, 90)),
                    (1100, ry)
                )
            except Exception:
                pass
            draw.text((1210, ry), f"{name.upper()[:35]}", fill=(255, 255, 255))
            draw.text(
                (1210, ry + 30),
                f"Delta-E: {de:.2f} | Delta-L: {dl:.1f} | {v}",
                fill=(160, 160, 160)
            )
            bw = int(_np.clip(450 - de * 8, 10, 450))
            draw.rectangle(
                [1210, ry + 75, 1210 + bw, ry + 85],
                fill=((0, 255, 130) if "MATCH" in v else (255, 100, 0))
            )

        if "Rescue" in mats:
            y_rescue_start = 1250
            draw.rectangle(
                [50, y_rescue_start - 20, 1850, y_rescue_start - 15],
                fill=(255, 120, 0)
            )
            draw.text(
                (50, y_rescue_start),
                "SEARCH & RESCUE OPERATIONS",
                fill=(255, 120, 0)
            )
            canvas.paste(
                _Image.fromarray(mats["Rescue"]).resize(
                    (420, 420), _Image.NEAREST
                ),
                (50, y_rescue_start + 50)
            )
            r_ranks = [r for r in ranks if r[4] is None]
            for i, (name, de, dl, v, p) in enumerate(r_ranks):
                rx = 520 + (i // 3) * 440
                ry = (y_rescue_start + 50) + (i % 3) * 120
                draw.rectangle(
                    [rx, ry, rx + 90, ry + 90],
                    fill=tuple(HIGH_VIS_STANDARDS[name])
                )
                draw.text((rx + 110, ry + 10), name.upper(), fill=(255, 255, 255))
                draw.text(
                    (rx + 110, ry + 40),
                    f"VISIBILITY: {de:.1f}",
                    fill=(200, 200, 200)
                )
                bw = int(_np.clip(de * 5.5, 10, 300))
                draw.rectangle(
                    [rx + 110, ry + 75, rx + 110 + bw, ry + 85],
                    fill=(255, 120, 0)
                )

        # QGIS: save to file, do NOT open webbrowser
        canvas.save(out_path)
        return out_path
