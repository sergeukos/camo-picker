# -*- coding: utf-8 -*-
from __future__ import annotations
"""
CamoPicker QGIS Plugin — engine_worker.py

Pipeline per polygon feature:
  1. Read raster pixels under polygon (correct dtype detection)
  2. [Optional] Spatial KMeans → N terrain sub-zones with pixel masks
  3. Per sub-zone: color KMeans → dominant colors → synthetic patterns
  4. Match synthetics against DB → best real pattern (or use synthetic)
  5. Compose per-zone tiles into one GeoTIFF per input polygon
"""

import os
from qgis.PyQt.QtCore import QObject, pyqtSignal
from qgis.core import (
    QgsGeometry, QgsRectangle, QgsCoordinateTransform,
    QgsProject, Qgis
)
from .tactical_core import TacticalCoreV12_1, ReporterV12, HIGH_VIS_STANDARDS

_DEPS_OK = None

def _check_deps():
    global _DEPS_OK
    if _DEPS_OK is not None:
        return _DEPS_OK
    try:
        import numpy; from PIL import Image
        from .colormath import KMeans
        _DEPS_OK = True
    except ImportError:
        _DEPS_OK = False
    return _DEPS_OK


class EngineWorker(QObject):
    progress = pyqtSignal(int)
    log_msg  = pyqtSignal(str)
    finished = pyqtSignal(dict)
    error    = pyqtSignal(str)

    def __init__(self, params):
        super().__init__()
        self.params = params
        self._stop  = False

    def request_stop(self):
        self._stop = True

    def run(self):
        if not _check_deps():
            self.error.emit(
                'Missing dependency: Pillow.\n'
                'In OSGeo4W Shell (as admin):\n'
                '  python -m pip install --target="C:\\Program Files\\QGIS 3.42.0\\apps\\Python312\\Lib\\site-packages" Pillow'
            )
            return
        try:
            self._run_pipeline()
        except Exception as exc:
            import traceback
            self.error.emit(str(exc) + '\n' + traceback.format_exc())

    # ------------------------------------------------------------------
    def _run_pipeline(self):
        import numpy as np
        from collections import Counter
        from .colormath import KMeans, rgb2lab, deltaE_ciede2000

        p             = self.params
        poly_layer    = p['polygon_layer']
        rast_layer    = p['raster_layer']
        k_color       = p['k_clusters']      # color clusters per sub-zone
        sample_res    = p['sample_res']
        mode          = p['mode']
        out_folder    = p['output_folder']
        save_report   = p['save_report']
        internal_cls  = p.get('internal_cls', True)
        n_zones       = p.get('n_zones', 3)
        auto_zones    = p.get('auto_zones', True)
        pat_mode      = p.get('pat_mode', 'synth')   # 'synth' | 'real_zone' | 'real_poly'
        biome_k       = p.get('biome_k', 3)
        temp_layer    = p.get('temp_layer', True)

        selected_only = p.get('selected_only', False)
        if selected_only and poly_layer.selectedFeatureCount() > 0:
            features = list(poly_layer.selectedFeatures())
            self.log_msg.emit(f'Using {len(features)} selected feature(s).')
        else:
            if selected_only:
                self.log_msg.emit('⚠ No selection found — using all features.')
            features = list(poly_layer.getFeatures())
        total      = len(features)
        if total == 0:
            self.error.emit('Polygon layer has no features.')
            return

        self.log_msg.emit(f'Found {total} polygon feature(s).')
        core     = TacticalCoreV12_1(headless=True)
        reporter = ReporterV12() if save_report else None

        self.log_msg.emit('Loading camouflage database…')
        try:
            core.load_db()
            offline = getattr(core, '_offline_mode', False)
            src = '📁 from local cache' if offline else '🌐 from GitHub'
            self.log_msg.emit(f'  DB: {len(core.db)} entries {src}.')
            if offline:
                self.log_msg.emit('  ℹ Offline mode — real patterns from cache only.')
        except ConnectionError as e:
            self.log_msg.emit(f'  ⚠ DB unavailable ({e}).')
            self.log_msg.emit('  ℹ No cache found — switching to synthetic patterns only.')
            if pat_mode != 'synth':
                pat_mode = 'synth'
                self.log_msg.emit('  ⚠ Pattern mode forced to: synthetic.')
        except Exception as e:
            self.log_msg.emit(f'  ⚠ DB error ({e}) — synthetic only.')
            pat_mode = 'synth'

        output_paths  = {}
        field_names   = [f.name() for f in poly_layer.fields()]

        for idx, feature in enumerate(features):
            if self._stop:
                self.log_msg.emit('⏹ Cancelled.')
                return

            base_pct = int(idx / total * 80)
            self.progress.emit(base_pct)
            zone_name = str(feature.attribute('name')) if 'name' in field_names else f'zone_{idx+1}'
            self.log_msg.emit(f'\n[{idx+1}/{total}] {zone_name}')

            # 1. Read raster pixels
            # Auto-compute sample resolution from polygon size + zoom
            if p.get('auto_res', True):
                sample_res = self._compute_sample_res(
                    feature.geometry(), poly_layer.crs(),
                    rast_layer.crs(), p.get('zoom', 17)
                )
                self.log_msg.emit(f'  Auto sample_res={sample_res}px (zoom={p.get("zoom",17)})')

            rgb_grid, mask_2d, bbox, crs = self._read_raster_grid(
                rast_layer, feature.geometry(), poly_layer.crs(),
                sample_res, p.get('zoom', 17)
            )
            if rgb_grid is None:
                self.log_msg.emit('  ⚠ Could not read raster — skipping.')
                continue

            H, W = rgb_grid.shape[:2]
            n_inside = int(mask_2d.sum())
            self.log_msg.emit(f'  Grid {W}×{H}, {n_inside} pixels inside polygon')

            flat_rgb  = rgb_grid.reshape(-1, 3)           # (H*W, 3)
            flat_mask = mask_2d.reshape(-1)               # (H*W,) bool

            # 2. Spatial KMeans — split polygon into terrain sub-zones
            if internal_cls and n_inside >= 2 * k_color:
                inside_px = flat_rgb[flat_mask].astype(np.float64)

                # Auto-detect optimal zone count via elbow method
                if auto_zones:
                    self.params['_base_pct'] = base_pct
                    self.log_msg.emit('  Elbow scan (K=2..8)…')
                    n_zones = self._elbow_zones(inside_px, k_min=2, k_max=8)
                    self.log_msg.emit(f'  Auto-detected {n_zones} terrain sub-zones')
                else:
                    n_zones = min(n_zones, n_inside // k_color)
                    self.log_msg.emit(f'  Classifying into {n_zones} terrain sub-zones (manual)')

                # Subsample for speed, then assign all pixels to nearest centroid
                MAX_FIT = 50_000
                if len(inside_px) > MAX_FIT:
                    idx_s  = np.random.RandomState(1).choice(len(inside_px), MAX_FIT, replace=False)
                    fit_px = inside_px[idx_s]
                else:
                    fit_px = inside_px
                km_spatial = KMeans(n_clusters=n_zones, n_init='auto', random_state=0)
                km_spatial.fit(fit_px)
                # Assign ALL inside pixels to nearest centroid
                dists = np.stack([
                    np.sum((inside_px - c)**2, axis=1)
                    for c in km_spatial.cluster_centers_
                ], axis=1)
                zone_labels_inside = np.argmin(dists, axis=1)

                zone_label_grid = np.full(H * W, -1, dtype=np.int32)
                zone_label_grid[flat_mask] = zone_labels_inside
                zone_label_grid = zone_label_grid.reshape(H, W)
            else:
                zone_label_grid = np.where(mask_2d, 0, -1)
                n_zones = 1

            # 3a. real_poly: one DB match for entire polygon
            poly_real_arr = None
            if pat_mode == 'real_poly' and core.db and mode != '3':
                self.log_msg.emit('  real_poly: finding best pattern for whole polygon…')
                flat_inside = flat_rgb[flat_mask].astype(np.float64)
                km_poly = KMeans(n_clusters=min(biome_k, len(flat_inside)),
                                 n_init='auto', random_state=42)
                km_poly.fit(flat_inside[:min(50_000, len(flat_inside))])
                cnt_poly = Counter(km_poly.labels_[:min(50_000, len(flat_inside))])
                n_poly   = min(50_000, len(flat_inside))
                doms_poly = [
                    [km_poly.cluster_centers_[i].tolist(), cnt_poly[i]/n_poly*100]
                    for i in range(km_poly.n_clusters)
                ]
                labs_poly = [float(rgb2lab(np.array([[d[0]]], dtype=np.float32)/255.0)[0,0,0]) for d in doms_poly]
                avg_l_poly = float(np.mean(labs_poly))
                entr_poly  = float(np.std(flat_inside))
                # rank_db_direct uses doms directly — no synthetic needed
                ranks_poly = core.rank_db_direct(doms_poly, avg_l_poly)
                if ranks_poly:
                    best_name_p, best_score_p, l_diff_p, verdict_p, _ = ranks_poly[0]
                    poly_real_arr = core._load_db_image(core.db[best_name_p])
                    self.log_msg.emit(
                        f'  Polygon best: {best_name_p}  score={best_score_p:.2f}  [{verdict_p}]'
                    )

            # 3b. Per sub-zone: get pattern, paint canvas
            canvas = np.zeros((H, W, 3), dtype=np.uint8)

            for z in range(n_zones):
                if self._stop:
                    return

                # Progress: base + classification share + per-zone share
                zone_pct = int(base_pct + 15 + (z / max(n_zones, 1)) * 60)
                self.progress.emit(min(95, zone_pct))

                z_mask = (zone_label_grid == z)
                n_z    = int(z_mask.sum())
                if n_z < k_color:
                    self.log_msg.emit(f'  Sub-zone {z}: too few pixels ({n_z}) — skipping.')
                    continue

                # Color KMeans for this sub-zone
                zone_px = flat_rgb[z_mask.reshape(-1)].astype(np.float64)
                km_c    = KMeans(n_clusters=min(k_color, n_z), n_init='auto', random_state=42)
                km_c.fit(zone_px)
                cnt  = Counter(km_c.labels_)
                doms = [
                    [km_c.cluster_centers_[i].tolist(), cnt[i] / n_z * 100]
                    for i in range(km_c.n_clusters)
                ]
                all_L = [
                    float(rgb2lab(np.array([[d[0]]], dtype=np.float32) / 255.0)[0, 0, 0])
                    for d in doms
                ]
                avg_l = float(np.mean(all_L))
                entr  = float(np.std(zone_px))

                self.log_msg.emit(f'  Sub-zone {z}: {n_z}px  L={avg_l:.1f}  entropy={entr:.1f}')

                # Generate synthetic patterns
                pivoted = core._apply_optical_pivot(doms, avg_l)
                mats    = {}
                if mode in ('1', '2'):
                    mats['Pixel']    = core.generate_pixel_apex(pivoted, entr)
                    mats['Spots']    = core.generate_spots_850(pivoted)
                    mats['Heritage'] = core.generate_heritage_woodland(pivoted)
                if mode in ('1', '3'):
                    mats['Rescue']   = core.generate_rescue_dazzle(doms)

                # Choose pattern based on mode + pat_mode
                pat_arr = None

                if mode == '3':
                    # RESCUE — always Hi-Vis, never from DB
                    pat_arr = mats.get('Rescue')
                    if pat_arr is None:
                        pat_arr = core.generate_rescue_dazzle(doms)
                    self.log_msg.emit('    → rescue Hi-Vis')

                elif pat_mode == 'real_poly' and poly_real_arr is not None:
                    pat_arr = poly_real_arr

                elif pat_mode == 'real_zone' and core.db:
                    ranks = core.rank_db_direct(doms, avg_l)
                    if ranks:
                        best_name, best_score, l_diff, verdict, path = ranks[0]
                        pat_arr = core._load_db_image(core.db[best_name])
                        self.log_msg.emit(
                            f'    → real_zone [{best_name}]  score={best_score:.2f}  ΔL={l_diff:.1f} [{verdict}]'
                        )

                if pat_arr is None:
                    # Choose synth pattern by zone characteristics
                    fb = self._select_synth_type(mats, entr, avg_l)
                    pat_arr = mats[fb]
                    label   = 'synthetic' if pat_mode == 'synth' else 'synthetic fallback'
                    self.log_msg.emit(f'    → {label} [{fb}]  (entropy={entr:.1f} L={avg_l:.1f})')

                # Tile pattern into canvas where this sub-zone lives
                from PIL import Image as PILImage
                tile   = PILImage.fromarray(pat_arr.astype(np.uint8)).resize((96, 96))
                tile_w, tile_h = tile.size
                # Build tiled background for full grid
                tiled = np.tile(
                    np.array(tile),
                    (H // tile_h + 2, W // tile_w + 2, 1)
                )[:H, :W]

                canvas[z_mask] = tiled[z_mask]

            # 4. Write GeoTIFF
            tiff = self._write_geotiff(canvas, mask_2d, bbox, crs, out_folder, zone_name, temp_layer)
            import datetime
            ts          = datetime.datetime.now().strftime('%H%M%S')
            pat_label   = ('rescue' if mode == '3' else
                           pat_mode.replace('real_poly','real-poly')
                                   .replace('real_zone','real-zone'))
            display_name = f'CamoPicker | {zone_name} | {pat_label} | {ts}'
            output_paths[display_name] = tiff
            self.log_msg.emit(f'  → {tiff}')

        self.progress.emit(100)
        self.finished.emit(output_paths)

    # ------------------------------------------------------------------
    def _read_raster_grid(self, rast_layer, geometry, poly_crs, sample_res, zoom=17):
        """
        Read raster as (H, W, 3) uint8 array + boolean mask.
        Handles any band dtype by normalising to 0-255.
        Returns (rgb_grid, mask_2d, bbox, crs) or (None,...) on failure.
        """
        import numpy as np
        from qgis.core import QgsCoordinateTransform

        rast_crs = rast_layer.crs()
        xform    = QgsCoordinateTransform(poly_crs, rast_crs, QgsProject.instance())
        geom_r   = QgsGeometry(geometry)
        geom_r.transform(xform)
        bbox = geom_r.boundingBox()

        if bbox.isEmpty() or bbox.width() == 0 or bbox.height() == 0:
            self.log_msg.emit('  ⚠ Empty bbox after reproject.')
            return None, None, None, None

        provider  = rast_layer.dataProvider()
        n_bands   = min(rast_layer.bandCount(), 3)
        if n_bands < 1:
            return None, None, None, None

        self.log_msg.emit(
            f'  Raster bands={rast_layer.bandCount()} '
            f'bbox={bbox.xMinimum():.1f},{bbox.yMinimum():.1f} → '
            f'{bbox.xMaximum():.1f},{bbox.yMaximum():.1f}'
        )

        # --- Strategy: render layer to QImage (works for WMS/WMTS/QMS and local) ---
        # Inset bbox by ~2% to avoid border contamination from neighbouring tiles/objects
        inset_x = bbox.width()  * 0.02
        inset_y = bbox.height() * 0.02
        from qgis.core import QgsRectangle
        bbox_inner = QgsRectangle(
            bbox.xMinimum() + inset_x, bbox.yMinimum() + inset_y,
            bbox.xMaximum() - inset_x, bbox.yMaximum() - inset_y
        )
        rgb_grid = self._render_layer_to_array(rast_layer, bbox_inner, sample_res)

        if rgb_grid is None:
            # Fallback: raw provider.block() read for local rasters
            self.log_msg.emit('  Renderer failed — trying raw provider read…')
            rgb_grid = self._raw_provider_read(provider, bbox, sample_res, n_bands)

        if rgb_grid is None:
            return None, None, None, None

        # Fast polygon mask via scanline rasterization
        # Use same bbox_inner for mask consistency with rendered image
        mask = self._rasterize_geometry(geom_r, bbox_inner, sample_res)
        return rgb_grid, mask, bbox_inner, rast_layer.crs()

    # ------------------------------------------------------------------
    def _select_synth_type(self, mats: dict, entropy: float, avg_l: float) -> str:
        """
        Choose which synthetic pattern type best suits the zone:

        Pixel Apex   — high entropy (complex texture: forest, urban)
        Heritage     — medium entropy + mid-dark luminance (mixed woodland)
        Spots 850    — low entropy (uniform terrain: field, desert, water)

        Thresholds tuned empirically for satellite imagery at zoom 15-18.
        """
        if 'Pixel' in mats and entropy >= 22.0:
            return 'Pixel'
        if 'Heritage' in mats and 12.0 <= entropy < 22.0 and avg_l < 65.0:
            return 'Heritage'
        if 'Spots' in mats:
            return 'Spots'
        # fallback: first available
        return list(mats.keys())[0]

    # ------------------------------------------------------------------
    def _elbow_zones(self, pixels, k_min=2, k_max=8, sample_n=2000):
        """
        Find optimal K via elbow method on KMeans inertia.
        Subsamples pixels for speed. Returns optimal K in [k_min, k_max].
        """
        import numpy as np
        from .colormath import KMeans

        # Subsample for speed
        if len(pixels) > sample_n:
            idx = np.random.RandomState(0).choice(len(pixels), sample_n, replace=False)
            X = pixels[idx]
        else:
            X = pixels

        inertias = []
        k_range  = list(range(k_min, k_max + 1))
        for ki, k in enumerate(k_range):
            km = KMeans(n_clusters=k, n_init=1, random_state=0)
            km.fit(X)
            inertia = float(np.sum((X - km.cluster_centers_[km.labels_]) ** 2))
            inertias.append(inertia)
            # Emit sub-progress during elbow scan
            self.progress.emit(int(self.params.get('_base_pct', 10) + ki * 2))

        # Elbow = point of maximum curvature (second derivative)
        if len(inertias) < 3:
            return k_min

        diffs1 = np.diff(inertias)           # first derivative
        diffs2 = np.diff(diffs1)             # second derivative
        elbow_idx = int(np.argmax(diffs2))   # max curvature = elbow
        return list(k_range)[elbow_idx + 1]  # +1 offset for double diff

    # ------------------------------------------------------------------
    def _compute_sample_res(self, geometry, poly_crs, rast_crs, zoom):
        """
        Compute pixel grid size so that 1 pixel ≈ 1 tile pixel at given zoom.
        zoom 17 → ~1.2m/px at equator.  Clamps to [128, 1024].
        """
        import numpy as np
        from qgis.core import QgsCoordinateTransform, QgsCoordinateReferenceSystem
        # Metres per pixel at given zoom (Web Mercator / equator)
        mpp = 156543.03 / (2 ** zoom)

        # Reproject bbox to metres (use raster CRS which is usually EPSG:3857)
        xform    = QgsCoordinateTransform(poly_crs, rast_crs, QgsProject.instance())
        geom_r   = geometry.__class__(geometry)
        geom_r.transform(xform)
        bbox     = geom_r.boundingBox()
        side_m   = max(bbox.width(), bbox.height())
        res      = int(np.clip(side_m / mpp, 128, 1024))
        return res

    # ------------------------------------------------------------------
    def _render_layer_to_array(self, rast_layer, bbox, size):
        """
        Render rast_layer into a (size, size, 3) uint8 RGB array
        using QGIS map renderer — correct for WMS/WMTS/QuickMapServices.
        Returns array or None on failure.
        """
        import numpy as np
        try:
            from qgis.core import (
                QgsMapSettings, QgsMapRendererCustomPainterJob,
                QgsRectangle, QgsCoordinateReferenceSystem
            )
            from qgis.PyQt.QtGui import QImage, QPainter
            from qgis.PyQt.QtCore import QSize, Qt

            settings = QgsMapSettings()
            settings.setLayers([rast_layer])
            settings.setOutputSize(QSize(size, size))
            settings.setExtent(bbox)
            settings.setDestinationCrs(rast_layer.crs())
            settings.setBackgroundColor(Qt.transparent)

            img = QImage(size, size, QImage.Format_ARGB32_Premultiplied)
            img.fill(0)
            painter = QPainter(img)

            job = QgsMapRendererCustomPainterJob(settings, painter)
            job.start()
            job.waitForFinished()
            painter.end()

            # QImage → numpy RGB
            img = img.convertToFormat(QImage.Format_RGB888)
            ptr = img.bits()
            ptr.setsize(img.sizeInBytes())
            arr = np.frombuffer(ptr, dtype=np.uint8).reshape(size, size, 3).copy()
            self.log_msg.emit(f'  Rendered {size}×{size} RGB via QgsMapRenderer')
            return arr

        except Exception as e:
            self.log_msg.emit(f'  ⚠ Renderer error: {e}')
            return None

    # ------------------------------------------------------------------
    def _raw_provider_read(self, provider, bbox, sample_res, n_bands):
        """Fallback: read raw provider blocks for local raster files."""
        import numpy as np
        try:
            from qgis.core import Qgis as _Q
            _TYPE_MAP = {
                _Q.DataType.Byte:    (np.uint8,   1),
                _Q.DataType.UInt16:  (np.uint16,  2),
                _Q.DataType.Int16:   (np.int16,   2),
                _Q.DataType.UInt32:  (np.uint32,  4),
                _Q.DataType.Int32:   (np.int32,   4),
                _Q.DataType.Float32: (np.float32, 4),
                _Q.DataType.Float64: (np.float64, 8),
            }
        except Exception:
            _TYPE_MAP = {}

        bands = []
        for b in range(1, n_bands + 1):
            blk = provider.block(b, bbox, sample_res, sample_res)
            raw = blk.data()
            try:
                raw_bytes = bytes(raw)
            except TypeError:
                raw_bytes = raw.data() if hasattr(raw, 'data') else b''
            if not raw_bytes:
                continue

            rdt             = provider.dataType(b)
            dtype, itemsize = _TYPE_MAP.get(rdt, (None, None))
            expected_px     = sample_res * sample_res
            if dtype is None:
                nb = len(raw_bytes)
                if nb == expected_px * 8:   dtype, itemsize = np.float64, 8
                elif nb == expected_px * 4: dtype, itemsize = np.float32, 4
                elif nb == expected_px * 2: dtype, itemsize = np.uint16,  2
                else:                       dtype, itemsize = np.uint8,   1

            n_bytes = expected_px * itemsize
            if len(raw_bytes) >= n_bytes:
                arr = np.frombuffer(raw_bytes[:n_bytes], dtype=dtype).reshape(sample_res, sample_res)
            else:
                padded = np.zeros(n_bytes, dtype=np.uint8)
                padded[:len(raw_bytes)] = np.frombuffer(raw_bytes, dtype=np.uint8)
                arr = np.frombuffer(padded.tobytes(), dtype=dtype).reshape(sample_res, sample_res)

            if dtype != np.uint8:
                a = arr.astype(np.float32)
                mn, mx = float(a.min()), float(a.max())
                arr = ((a - mn) / (mx - mn) * 255).astype(np.uint8) if mx > mn else np.zeros_like(a, dtype=np.uint8)

            bands.append(arr)

        if not bands:
            return None
        while len(bands) < 3:
            bands.append(bands[-1])
        return np.stack(bands[:3], axis=-1)

    # ------------------------------------------------------------------
    def _rasterize_geometry(self, geom, bbox, size):
        """
        Vectorised polygon rasterisation — replaces the slow per-pixel loop.
        Fallback chain: rasterio.features → shapely → slow QgsPointXY loop.
        """
        import numpy as np
        import json

        xs = np.linspace(bbox.xMinimum(), bbox.xMaximum(), size)
        ys = np.linspace(bbox.yMaximum(), bbox.yMinimum(), size)

        # Strategy 1: rasterio.features (GDAL-backed, ~500x faster)
        try:
            import rasterio.features
            from rasterio.transform import from_bounds
            transform = from_bounds(
                bbox.xMinimum(), bbox.yMinimum(),
                bbox.xMaximum(), bbox.yMaximum(),
                size, size
            )
            geojson = json.loads(geom.asJson())
            burned  = rasterio.features.rasterize(
                [(geojson, 1)],
                out_shape=(size, size),
                transform=transform,
                fill=0, dtype=np.uint8
            )
            self.log_msg.emit(f'  Mask: {int(burned.sum())}/{size*size}px (rasterio)')
            return burned.astype(bool)
        except Exception as e1:
            self.log_msg.emit(f'  rasterio mask failed ({e1}), trying shapely…')

        # Strategy 2: shapely vectorised (~100x faster)
        try:
            from shapely.geometry import shape
            from shapely.vectorized import contains
            shp      = shape(json.loads(geom.asJson()))
            xg, yg   = np.meshgrid(xs, ys)
            mask     = contains(shp, xg.ravel(), yg.ravel()).reshape(size, size)
            self.log_msg.emit(f'  Mask: {int(mask.sum())}/{size*size}px (shapely)')
            return mask
        except Exception as e2:
            self.log_msg.emit(f'  shapely failed ({e2}), using slow fallback…')

        # Strategy 3: slow fallback
        from qgis.core import QgsPointXY
        xg, yg = np.meshgrid(xs, ys)
        mask   = np.zeros((size, size), dtype=bool)
        for r in range(size):
            for c in range(size):
                if geom.contains(QgsPointXY(float(xg[r, c]), float(yg[r, c]))):
                    mask[r, c] = True
        self.log_msg.emit(f'  Mask: {int(mask.sum())}/{size*size}px (slow fallback)')
        return mask

    # ------------------------------------------------------------------
    def _write_geotiff(self, canvas, mask_2d, bbox, crs, out_folder, zone_name, use_temp=True):
        """
        Write canvas as GeoTIFF with polygon mask applied:
        - pixels outside polygon → fully transparent (alpha=0)
        - uses RGBA with alpha channel so QGIS renders clipped shape
        """
        import numpy as np
        from PIL import Image

        import tempfile, uuid
        H, W = canvas.shape[:2]

        # Build alpha channel: 255 inside polygon, 0 outside
        alpha = (mask_2d.astype(np.uint8) * 255)
        rgba  = np.dstack([canvas, alpha])   # (H, W, 4)

        # Unique filename to avoid file-lock conflicts on re-run
        uid  = uuid.uuid4().hex[:6]
        fname = f'camo_{zone_name}_{uid}.tif'

        try:
            import rasterio
            from rasterio.transform import from_bounds
            from rasterio.crs import CRS
            if use_temp:
                path = os.path.join(tempfile.gettempdir(), fname)
            else:
                path = os.path.join(out_folder, fname)
            auth  = crs.authid()
            epsg  = int(auth.split(':')[1]) if ':' in auth else 4326
            xform = from_bounds(
                bbox.xMinimum(), bbox.yMinimum(),
                bbox.xMaximum(), bbox.yMaximum(), W, H
            )
            with rasterio.open(path, 'w', driver='GTiff', height=H, width=W,
                               count=4, dtype='uint8',
                               crs=CRS.from_epsg(epsg), transform=xform) as dst:
                for b in range(4):
                    dst.write(rgba[:, :, b], b + 1)
                # Mark band 4 as alpha so QGIS auto-detects transparency
                dst.update_tags(ns='rio_overview', resampling='nearest')
            return path
        except ImportError:
            # Fallback: PNG with transparency
            path = os.path.join(tempfile.gettempdir() if use_temp else out_folder, f'camo_{zone_name}_{uid}.png')
            Image.fromarray(rgba, 'RGBA').save(path)
            self.log_msg.emit('  ℹ rasterio missing — saved RGBA PNG (no georef).')
            return path
